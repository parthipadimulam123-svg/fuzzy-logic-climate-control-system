"""Optional Gemini-powered recommendations with an offline fallback.

Set GEMINI_API_KEY (and optionally GEMINI_MODEL) to enable the cloud call.
No third-party packages required (uses urllib).
"""
from __future__ import annotations

import json
import os
import urllib.request

from .controller import ClimateController

DEFAULT_MODEL = "gemini-3-flash-preview"


def build_prompt(c: ClimateController) -> str:
    return (
        "Act as an expert HVAC Thermal AI Architect. Analyze this enterprise facility state:\n"
        f'Zone: "{c.zone_name}" (Capacity: {c.capacity})\n'
        f"Current Occupants: {c.occupancy} people\n"
        f"Indoor Temp: {c.indoor_temp}°C, Outdoor Temp: {c.outdoor_temp}°C, Humidity: {c.humidity}%\n"
        f"Calculated Body Heat Load: {c.occupancy * 400} BTU/hr\n"
        f'Fuzzy Engine Output: Fan Speed {c.fan_speed}%, Compressor {c.compressor_duty}%, Mode "{c.hvac_mode}"\n\n'
        "Provide a concise 3-bullet point executive recommendation covering:\n"
        "1. Recommended Target Temperature Setpoint (°C).\n"
        "2. Energy saving optimization tip.\n"
        "3. Air quality / CO2 mitigation strategy."
    )


def local_recommendation(c: ClimateController) -> str:
    target = 21.5 if c.occupancy > 150 else 23.5
    return (
        "AI Thermal Audit Complete (Local Backup Engine)\n"
        f"• Optimal Setpoint: Adjust VAV terminal units to {target}°C to offset human sensible heat rise.\n"
        "• Efficiency Mode: Pre-cool zone by 1.5°C before peak crowd arrival to reduce grid peak charges.\n"
        f"• Air Quality: Increase VFD damper opening to {c.last_metrics.damper_pct + 10}% "
        "to keep CO₂ levels under 700 PPM."
    )


def get_recommendation(c: ClimateController, timeout: float = 20.0) -> str:
    key = os.environ.get("GEMINI_API_KEY", "")
    if not key:
        return local_recommendation(c)
    model = os.environ.get("GEMINI_MODEL", DEFAULT_MODEL)
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    body = json.dumps({"contents": [{"parts": [{"text": build_prompt(c)}]}]}).encode()
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/json", "x-goog-api-key": key})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.load(resp)
        text = data["candidates"][0]["content"]["parts"][0]["text"]
        return text or local_recommendation(c)
    except Exception:
        return local_recommendation(c)
