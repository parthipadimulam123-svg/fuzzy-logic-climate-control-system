"""Enterprise zones and one-click crowd presets."""
from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class Zone:
    name: str
    capacity: int
    icon: str = ""


ZONES: Dict[str, Zone] = {z.name: z for z in [
    Zone("Tech Office Open Workspace", 250, "💻"),
    Zone("Executive Boardroom", 40, "🤝"),
    Zone("Mall Main Atrium", 800, "🛍️"),
    Zone("Mall Food Court", 500, "🍔"),
    Zone("Data Center Annex", 20, "🖥️"),
]}


@dataclass(frozen=True)
class Preset:
    key: str
    label: str
    zone: str
    occupancy: int
    indoor_temp: float


PRESETS: Dict[str, Preset] = {p.key: p for p in [
    Preset("morning", "Morning Rush", "Tech Office Open Workspace", 200, 27.0),
    Preset("lunch", "Food Court Peak", "Mall Food Court", 420, 29.5),
    Preset("night", "Night Shift", "Tech Office Open Workspace", 25, 22.0),
    Preset("sale", "Weekend Sale", "Mall Main Atrium", 720, 31.0),
]}
