"""Triangular and trapezoidal membership functions.

Ported from the original JavaScript. One deliberate fix: the JS used a 1e-5
divisor for degenerate edges (a == b or c == d), which made membership drop to
0 *exactly* at a shoulder boundary (e.g. High occupancy at 100% capacity).
Here a degenerate edge is treated as a vertical edge, so shoulders hold 1.0.
"""


def _rise(x: float, a: float, b: float) -> float:
    if b == a:
        return 1.0 if x >= a else 0.0
    return (x - a) / (b - a)


def _fall(x: float, c: float, d: float) -> float:
    if d == c:
        return 1.0 if x <= c else 0.0
    return (d - x) / (d - c)


def trimf(x: float, a: float, b: float, c: float) -> float:
    """Triangular membership function with feet at a, c and peak at b."""
    return max(0.0, min(_rise(x, a, b), _fall(x, b, c)))


def trapmf(x: float, a: float, b: float, c: float, d: float) -> float:
    """Trapezoidal membership function with feet a, d and plateau b..c."""
    return max(0.0, min(_rise(x, a, b), 1.0, _fall(x, c, d)))
