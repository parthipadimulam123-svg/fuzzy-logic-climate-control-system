"""Stateful controller: holds the live system state, telemetry history and reports."""
from __future__ import annotations

import csv
import io
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Deque, Dict, List, Optional

from .engine import RULES, FuzzyResult, infer
from .thermal import ThermalMetrics, compute_metrics
from .zones import PRESETS, ZONES


@dataclass
class ClimateController:
    zone_name: str = "Tech Office Open Workspace"
    occupancy: int = 142
    indoor_temp: float = 26.5
    outdoor_temp: float = 32.0
    humidity: int = 62
    manual_override: bool = False
    history_len: int = 11

    # live outputs (retained while manual override is on)
    fan_speed: float = 68.4
    compressor_duty: float = 72.0
    hvac_mode: str = "Balanced Cool"

    last_result: Optional[FuzzyResult] = field(default=None, init=False)
    last_metrics: Optional[ThermalMetrics] = field(default=None, init=False)
    history: Dict[str, Deque] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        self.history = {k: deque(maxlen=self.history_len) for k in ("time", "occ", "temp", "power")}
        self.update()

    # ---- state mutation -------------------------------------------------
    @property
    def capacity(self) -> int:
        return ZONES[self.zone_name].capacity

    def set_zone(self, name: str) -> None:
        if name not in ZONES:
            raise ValueError(f"Unknown zone: {name!r}")
        self.zone_name = name
        self.occupancy = min(self.occupancy, self.capacity)
        self.update()

    def adjust_occupancy(self, delta: int) -> None:
        self.occupancy = max(0, min(1000, self.occupancy + delta))
        self.update()

    def apply_preset(self, key: str) -> None:
        p = PRESETS[key]
        self.zone_name = p.zone
        self.occupancy = p.occupancy
        self.indoor_temp = p.indoor_temp
        self.update()

    # ---- core step ------------------------------------------------------
    def update(self) -> ThermalMetrics:
        res = infer(self.occupancy, self.capacity, self.indoor_temp)
        if res.crisp_valid and not self.manual_override:
            self.fan_speed = res.fan_speed
            self.compressor_duty = res.compressor_duty
            self.hvac_mode = res.hvac_mode
        self.last_result = res
        self.last_metrics = compute_metrics(self.occupancy, self.capacity, self.humidity,
                                            self.fan_speed, self.compressor_duty)
        return self.last_metrics

    def record_telemetry(self) -> None:
        m = self.last_metrics
        self.history["time"].append(datetime.now().strftime("%H:%M:%S"))
        self.history["occ"].append(self.occupancy)
        self.history["temp"].append(self.indoor_temp)
        self.history["power"].append(m.power_kw)

    # ---- reporting ------------------------------------------------------
    def rule_table(self) -> List[dict]:
        return [{"Rule": r.id, "Description": r.name,
                 "Firing strength (mu)": round(self.last_result.rule_weights[r.id], 2)}
                for r in RULES]

    def report_text(self) -> str:
        m = self.last_metrics
        pct = round(self.occupancy / self.capacity * 100)
        return "\n".join([
            "Executive Thermal Audit & Fuzzy Logic Report",
            "=" * 44,
            f"Facility Zone     : {self.zone_name}",
            f"Timestamp         : {datetime.now():%Y-%m-%d %H:%M:%S}",
            f"Occupancy         : {self.occupancy} persons ({pct}% load)",
            f"Body heat load    : {m.btu_per_hr:,} BTU/hr",
            f"Fresh-air damper  : {m.damper_pct}%",
            f"HVAC mode         : {self.hvac_mode}",
            f"Fan VFD speed     : {self.fan_speed}% PWM",
            f"Compressor duty   : {self.compressor_duty}%",
            "Defuzzification   : Centre of Gravity (weighted average)",
        ])

    def export_csv(self) -> str:
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Timestamp", "Zone", "Occupants", "AmbientTemp", "OutdoorTemp",
                    "Humidity", "FanPWM", "CompressorDuty", "PowerKW"])
        w.writerow([datetime.now().isoformat(), self.zone_name, self.occupancy,
                    self.indoor_temp, self.outdoor_temp, self.humidity,
                    self.fan_speed, self.compressor_duty, self.last_metrics.power_kw])
        return buf.getvalue()
