"""Mamdani-style fuzzy inference engine with centre-of-gravity style defuzzification.

Inputs : occupancy ratio (% of zone capacity) and indoor temperature (deg C)
Outputs: fan VFD speed (%), compressor duty (%), dominant HVAC mode
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from .membership import trapmf, trimf


@dataclass(frozen=True)
class Rule:
    id: int
    occupancy: str      # "Low" | "Medium" | "High"
    temperature: str    # "Cold" | "Optimal" | "Hot"
    fan: float          # consequent fan speed (%)
    compressor: float   # consequent compressor duty (%)
    mode: str
    description: str

    @property
    def name(self) -> str:
        return f"IF Occupancy is {self.occupancy} AND Temp is {self.temperature} THEN {self.description}"


RULES: List[Rule] = [
    Rule(1, "Low", "Cold", 25, 20, "Eco Purge", "Fan PWM Low, Chiller Eco"),
    Rule(2, "Low", "Optimal", 40, 35, "Eco Cool", "Fan PWM Med-Low, Chiller Eco"),
    Rule(3, "Low", "Hot", 60, 65, "Balanced Cool", "Fan PWM Med, Chiller Balanced"),
    Rule(4, "Medium", "Cold", 45, 30, "Eco Purge", "Fan PWM Med, Chiller Eco"),
    Rule(5, "Medium", "Optimal", 65, 60, "Balanced Cool", "Fan PWM Med-High, Chiller Balanced"),
    Rule(6, "Medium", "Hot", 85, 85, "Turbo Cool", "Fan PWM High, Chiller Turbo"),
    Rule(7, "High", "Cold", 75, 50, "Smart Purge", "Fan PWM High, Fresh Air Max"),
    Rule(8, "High", "Optimal", 88, 80, "Turbo Cool", "Fan PWM High, Chiller High"),
    Rule(9, "High", "Hot", 100, 100, "Max Turbo Cool", "Fan PWM Max (100%), Chiller Max (100%)"),
]


def fuzzify_occupancy(occ_ratio_pct: float) -> Dict[str, float]:
    return {
        "Low": trapmf(occ_ratio_pct, 0, 0, 20, 45),
        "Medium": trimf(occ_ratio_pct, 30, 50, 75),
        "High": trapmf(occ_ratio_pct, 60, 80, 100, 100),
    }


def fuzzify_temperature(temp_c: float) -> Dict[str, float]:
    return {
        "Cold": trapmf(temp_c, 16, 16, 20, 22.5),
        "Optimal": trimf(temp_c, 21.5, 24.0, 26.5),
        "Hot": trapmf(temp_c, 25.5, 28.5, 40, 40),
    }


@dataclass
class FuzzyResult:
    occupancy_sets: Dict[str, float]
    temperature_sets: Dict[str, float]
    rule_weights: Dict[int, float]      # rule id -> firing strength
    fan_speed: float                    # %
    compressor_duty: float              # %
    hvac_mode: str
    crisp_valid: bool                   # False when no rule fired (outputs unchanged)


def infer(occupancy: float, zone_capacity: float, indoor_temp: float) -> FuzzyResult:
    """Run the full fuzzify -> rule evaluation -> defuzzify pipeline."""
    occ_ratio = min(100.0, (occupancy / zone_capacity) * 100.0)
    occ_sets = fuzzify_occupancy(occ_ratio)
    temp_sets = fuzzify_temperature(indoor_temp)

    weights: Dict[int, float] = {}
    total = weighted_fan = weighted_comp = 0.0
    max_w, dominant = -1.0, "Balanced Cool"

    for r in RULES:
        w = min(occ_sets[r.occupancy], temp_sets[r.temperature])  # Mamdani AND = min
        weights[r.id] = w
        total += w
        weighted_fan += w * r.fan
        weighted_comp += w * r.compressor
        if w > max_w:
            max_w, dominant = w, r.mode

    if total > 0:
        return FuzzyResult(occ_sets, temp_sets, weights,
                           round(weighted_fan / total, 1),
                           round(weighted_comp / total, 1),
                           dominant, True)
    return FuzzyResult(occ_sets, temp_sets, weights, 0.0, 0.0, dominant, False)
