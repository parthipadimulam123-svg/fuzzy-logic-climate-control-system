"""Thermal / energy estimates derived from occupancy and fuzzy outputs."""
import math
from dataclasses import dataclass

BTU_PER_PERSON_HR = 400
TARIFF_PER_KWH = 0.15


def js_round(x: float) -> int:
    """Round half up (matches JavaScript Math.round, unlike Python's banker's rounding)."""
    return int(math.floor(x + 0.5))


@dataclass
class ThermalMetrics:
    btu_per_hr: int
    co2_ppm: int
    power_kw: float
    cost_per_hr: float
    damper_pct: int
    density: str


def fresh_air_damper(occ_ratio_pct: float, humidity: float) -> int:
    return int(min(100, max(15, js_round(occ_ratio_pct * 0.6 + humidity * 0.25))))


def power_kw(fan_pct: float, compressor_pct: float) -> float:
    return js_round((fan_pct * 0.12 + compressor_pct * 0.22) * 10) / 10


def density_label(cap_ratio: float) -> str:
    if cap_ratio > 0.8:
        return "High Density"
    if cap_ratio < 0.25:
        return "Low Sparse"
    return "Optimal"


def compute_metrics(occupancy: int, capacity: int, humidity: float,
                    fan_pct: float, compressor_pct: float) -> ThermalMetrics:
    occ_ratio = min(100.0, occupancy / capacity * 100.0)
    kw = power_kw(fan_pct, compressor_pct)
    return ThermalMetrics(
        btu_per_hr=occupancy * BTU_PER_PERSON_HR,
        co2_ppm=js_round(400 + occupancy * 1.55),
        power_kw=kw,
        cost_per_hr=round(kw * TARIFF_PER_KWH, 2),
        damper_pct=fresh_air_damper(occ_ratio, humidity),
        density=density_label(occupancy / capacity),
    )
