"""Command-line interface:  python -m fuzzy_climate.cli --help"""
import argparse

from .ai_advisor import get_recommendation
from .controller import ClimateController
from .zones import PRESETS, ZONES


def main(argv=None) -> None:
    p = argparse.ArgumentParser(description="Fuzzy logic smart occupancy & climate control")
    p.add_argument("--zone", default="Tech Office Open Workspace", choices=list(ZONES))
    p.add_argument("--occupancy", type=int, default=142)
    p.add_argument("--indoor", type=float, default=26.5, help="indoor temp (C)")
    p.add_argument("--outdoor", type=float, default=32.0, help="outdoor temp (C)")
    p.add_argument("--humidity", type=int, default=62, help="relative humidity (%%)")
    p.add_argument("--preset", choices=list(PRESETS), help="overrides zone/occupancy/indoor temp")
    p.add_argument("--ai", action="store_true", help="print AI recommendation")
    p.add_argument("--csv", metavar="FILE", help="write a CSV snapshot")
    a = p.parse_args(argv)

    c = ClimateController(zone_name=a.zone, occupancy=a.occupancy, indoor_temp=a.indoor,
                          outdoor_temp=a.outdoor, humidity=a.humidity)
    if a.preset:
        c.apply_preset(a.preset)

    m = c.last_metrics
    print(c.report_text())
    print(f"CO2 estimate      : {m.co2_ppm} PPM")
    print(f"HVAC power        : {m.power_kw} kW (${m.cost_per_hr:.2f}/hr)")
    print(f"Density           : {m.density}\n")
    print("Active rules:")
    for row in c.rule_table():
        if row["Firing strength (mu)"] > 0:
            print(f"  #{row['Rule']}  mu={row['Firing strength (mu)']:.2f}  {row['Description']}")
    if a.ai:
        print("\n" + get_recommendation(c))
    if a.csv:
        with open(a.csv, "w", newline="", encoding="utf-8") as f:
            f.write(c.export_csv())
        print(f"\nCSV written to {a.csv}")


if __name__ == "__main__":
    main()
