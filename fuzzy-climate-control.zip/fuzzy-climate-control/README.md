# AuraClimate – Fuzzy Logic Smart Occupancy & Climate Control

A Python implementation of a **Mamdani-style fuzzy logic HVAC controller** that
adjusts fan speed, compressor duty and fresh-air damper position based on zone
occupancy and indoor temperature. Ported from an HTML/JavaScript dashboard.

## Features
- Fuzzy inference engine: triangular/trapezoidal membership functions, 9 rules,
  weighted-average (centre-of-gravity style) defuzzification
- Thermal estimates: body heat load (BTU/hr), CO₂, power (kW), cost, damper %
- 5 enterprise zones and 4 crowd presets (morning rush, food court peak, night shift, weekend sale)
- Manual override (freezes fuzzy outputs)
- Optional Gemini AI recommendations with an offline fallback
- CSV export and text report
- Interactive Streamlit dashboard + zero-dependency CLI

## Project layout
```
fuzzy_climate/
  membership.py   trimf / trapmf
  engine.py       rules, fuzzification, inference, defuzzification
  thermal.py      BTU, CO2, power, cost, damper
  zones.py        zones and presets
  controller.py   live state, telemetry, report, CSV
  ai_advisor.py   Gemini call + local fallback
  cli.py          command-line interface
app.py            Streamlit dashboard
tests/            unit tests
```

## Quick start
```bash
git clone <your-repo-url> && cd fuzzy-climate-control

# CLI (no dependencies)
python -m fuzzy_climate.cli --preset lunch
python -m fuzzy_climate.cli --zone "Mall Main Atrium" --occupancy 600 --indoor 29 --csv out.csv

# Dashboard
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py

# Tests
python -m unittest discover -s tests -v
```

### Use as a library
```python
from fuzzy_climate import ClimateController

c = ClimateController(occupancy=300, indoor_temp=29.0)
print(c.fan_speed, c.compressor_duty, c.hvac_mode)
```

### Optional: Gemini recommendations
```bash
export GEMINI_API_KEY=your_key        # Windows PowerShell: $env:GEMINI_API_KEY="your_key"
export GEMINI_MODEL=gemini-3-flash-preview   # optional
```
Without a key (or if the call fails) a local heuristic recommendation is used.
**Never commit your API key** – `.env` is git-ignored.

## How the fuzzy logic works
| Input | Sets |
|---|---|
| Occupancy (% of capacity) | Low, Medium, High |
| Indoor temperature (°C) | Cold, Optimal, Hot |

Each of the 9 rules fires with strength `min(occupancy_mu, temperature_mu)`.
Fan and compressor outputs are the firing-strength-weighted average of each
rule's consequent value; the dominant mode comes from the strongest rule.

## Notes on the port
- The browser-only login screen, Three.js background and Chart.js widgets were
  replaced by the Streamlit UI (not needed for the control logic).
- Membership functions: shoulders now hold μ = 1.0 exactly at the boundary
  (the JS version dropped to 0 at e.g. 100 % occupancy).

## License
MIT
