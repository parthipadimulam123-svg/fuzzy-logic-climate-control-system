"""Streamlit dashboard:  streamlit run app.py"""
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

from fuzzy_climate import ClimateController
from fuzzy_climate.ai_advisor import get_recommendation
from fuzzy_climate.engine import fuzzify_occupancy, fuzzify_temperature
from fuzzy_climate.zones import PRESETS, ZONES

st.set_page_config(page_title="AuraClimate – Fuzzy HVAC", page_icon="🌀", layout="wide")

if "ctrl" not in st.session_state:
    st.session_state.ctrl = ClimateController()
    st.session_state.ai_text = ""
    st.session_state.setdefault("zone", "Tech Office Open Workspace")
    st.session_state.setdefault("occ", 142)
    st.session_state.setdefault("t_in", 26.5)

c: ClimateController = st.session_state.ctrl


def _preset(key: str) -> None:
    p = PRESETS[key]
    st.session_state.zone, st.session_state.occ, st.session_state.t_in = p.zone, p.occupancy, p.indoor_temp


# ---------------- sidebar ----------------
with st.sidebar:
    st.title("🌀 AuraClimate")
    st.caption("Mamdani fuzzy HVAC control")
    zone = st.selectbox("Zone", list(ZONES), key="zone",
                        format_func=lambda n: f"{ZONES[n].icon} {n} (cap {ZONES[n].capacity})")
    cap = ZONES[zone].capacity
    st.session_state.occ = min(st.session_state.occ, cap)
    occ = st.slider("Occupancy", 0, cap, key="occ")
    t_in = st.slider("Indoor temp (°C)", 16.0, 38.0, step=0.5, key="t_in")
    t_out = st.slider("Outdoor temp (°C)", 10.0, 45.0, 32.0, 0.5)
    hum = st.slider("Relative humidity (%)", 20, 95, 62)
    override = st.checkbox("Manual override (freeze outputs)")

    st.markdown("**Presets**")
    cols = st.columns(2)
    for i, p in enumerate(PRESETS.values()):
        cols[i % 2].button(p.label, on_click=_preset, args=(p.key,), use_container_width=True)

c.zone_name, c.occupancy, c.indoor_temp = zone, occ, t_in
c.outdoor_temp, c.humidity, c.manual_override = t_out, hum, override
m = c.update()
c.record_telemetry()

# ---------------- KPIs ----------------
st.title("Smart Occupancy & Climate Control")
st.caption(f"Current zone: **{zone}**")
k = st.columns(4)
k[0].metric("Occupants", c.occupancy, m.density)
k[1].metric("Fan VFD", f"{round(c.fan_speed)}%", c.hvac_mode, delta_color="off")
k[2].metric("Body heat load", f"{m.btu_per_hr / 1000:.1f}k BTU/hr", f"CO₂ ≈ {m.co2_ppm} ppm", delta_color="off")
k[3].metric("HVAC power", f"{m.power_kw} kW", f"${m.cost_per_hr:.2f}/hr", delta_color="off")

left, right = st.columns([1, 1])

# ---------------- membership functions ----------------
with left:
    st.subheader("Membership functions")
    tab_occ, tab_temp = st.tabs(["Occupancy", "Temperature"])

    def _plot(xs, fn, live_x, xlabel):
        fig, ax = plt.subplots(figsize=(5, 2.6))
        sets = {k: [] for k in fn(xs[0])}
        for x in xs:
            for k_, v in fn(x).items():
                sets[k_].append(v)
        for name, ys in sets.items():
            ax.plot(xs, ys, label=name)
            ax.fill_between(xs, ys, alpha=0.12)
        ax.axvline(live_x, color="k", ls="--")
        ax.set_xlabel(xlabel); ax.set_ylabel("μ"); ax.legend(fontsize=7)
        fig.tight_layout()
        return fig

    with tab_occ:
        st.pyplot(_plot(np.linspace(0, 100, 201), fuzzify_occupancy,
                        min(100, c.occupancy / c.capacity * 100), "% of capacity"))
    with tab_temp:
        st.pyplot(_plot(np.linspace(16, 38, 221), fuzzify_temperature, c.indoor_temp, "°C"))

# ---------------- outputs & rules ----------------
with right:
    st.subheader("Fuzzy outputs")
    o = st.columns(3)
    o[0].metric("Fan VFD speed", f"{c.fan_speed}%")
    o[1].metric("Compressor duty", f"{c.compressor_duty}%")
    o[2].metric("Fresh-air damper", f"{m.damper_pct}%")
    st.subheader("Rule firing matrix")
    df = pd.DataFrame(c.rule_table())
    st.dataframe(df, hide_index=True, use_container_width=True,
                 column_config={"Firing strength (mu)": st.column_config.ProgressColumn(
                     "μ", min_value=0.0, max_value=1.0, format="%.2f")})

# ---------------- telemetry ----------------
st.subheader("Telemetry")
hist = st.session_state.setdefault("hist", [])
hist.append({"time": pd.Timestamp.now(), "Occupancy": c.occupancy,
             "Indoor temp (°C)": c.indoor_temp, "Power (kW)": m.power_kw})
del hist[:-60]
st.line_chart(pd.DataFrame(hist).set_index("time"))

# ---------------- AI + report ----------------
a, b = st.columns(2)
with a:
    st.subheader("AI Climate Architect")
    st.caption("Uses Gemini if GEMINI_API_KEY is set, otherwise an offline heuristic.")
    if st.button("Run thermal reasoner"):
        with st.spinner("Analyzing thermal dynamics..."):
            st.session_state.ai_text = get_recommendation(c)
    if st.session_state.ai_text:
        st.info(st.session_state.ai_text)
with b:
    st.subheader("Executive report")
    st.code(c.report_text())
    st.download_button("Export CSV", c.export_csv(), file_name="HVAC_Fuzzy_Report.csv", mime="text/csv")
