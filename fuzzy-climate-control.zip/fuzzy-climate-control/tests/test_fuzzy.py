import unittest

from fuzzy_climate import ClimateController, infer, trapmf, trimf
from fuzzy_climate.thermal import fresh_air_damper, js_round


class MembershipTests(unittest.TestCase):
    def test_trimf_peak_and_feet(self):
        self.assertEqual(trimf(24, 21.5, 24, 26.5), 1.0)
        self.assertEqual(trimf(21.5, 21.5, 24, 26.5), 0.0)
        self.assertEqual(trimf(30, 21.5, 24, 26.5), 0.0)

    def test_trapmf_plateau_and_shoulders(self):
        self.assertEqual(trapmf(10, 0, 0, 20, 45), 1.0)   # left shoulder (a == b)
        self.assertEqual(trapmf(100, 60, 80, 100, 100), 1.0)  # right shoulder (c == d)
        self.assertAlmostEqual(trapmf(32.5, 0, 0, 20, 45), 0.5)


class EngineTests(unittest.TestCase):
    def test_default_state(self):
        r = infer(142, 250, 26.5)
        self.assertTrue(r.crisp_valid)
        self.assertEqual((r.fan_speed, r.compressor_duty, r.hvac_mode), (85.0, 85.0, "Turbo Cool"))

    def test_max_load_triggers_rule_9(self):
        r = infer(420, 500, 29.5)
        self.assertEqual(r.fan_speed, 100.0)
        self.assertEqual(r.compressor_duty, 100.0)
        self.assertEqual(r.hvac_mode, "Max Turbo Cool")

    def test_low_cold_triggers_eco_purge(self):
        r = infer(5, 250, 17)
        self.assertEqual(r.hvac_mode, "Eco Purge")
        self.assertEqual(r.fan_speed, 25.0)

    def test_full_capacity_counts_as_high(self):
        r = infer(250, 250, 30.0)
        self.assertEqual(r.occupancy_sets["High"], 1.0)


class ControllerTests(unittest.TestCase):
    def test_manual_override_freezes_outputs(self):
        c = ClimateController()
        fan = c.fan_speed
        c.manual_override = True
        c.occupancy = 250
        c.update()
        self.assertEqual(c.fan_speed, fan)

    def test_zone_change_clamps_occupancy(self):
        c = ClimateController(occupancy=200)
        c.set_zone("Executive Boardroom")
        self.assertEqual(c.occupancy, 40)

    def test_presets(self):
        c = ClimateController()
        c.apply_preset("sale")
        self.assertEqual((c.zone_name, c.occupancy), ("Mall Main Atrium", 720))

    def test_csv_export_has_header_and_row(self):
        self.assertEqual(len(ClimateController().export_csv().strip().splitlines()), 2)


class ThermalTests(unittest.TestCase):
    def test_js_round_half_up(self):
        self.assertEqual(js_round(2.5), 3)
        self.assertEqual(js_round(0.5), 1)

    def test_damper_bounds(self):
        self.assertEqual(fresh_air_damper(0, 20), 15)
        self.assertEqual(fresh_air_damper(100, 95), 84)


if __name__ == "__main__":
    unittest.main()
